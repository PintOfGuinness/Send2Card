'use strict';

/**
 * @ngdoc service
 * @name send2CardApp.send2CardService
 * @description
 * # send2CardService
 * Service in the send2CardApp.
 */
angular.module('send2CardApp')
    .service('sendToCardService', function send2CardService($http) {

        var sendToCardResults = [];
        var service = {
            sendToCardResults: sendToCardResults,
            sendToCard: sendToCard
        };
        return service;

        function sendToCard(URL, requestBody) {
            return $http({
                method: 'POST',
                url: URL,
                data: requestBody
            }).then(function (results) {
                //Success
                angular.copy(results.data, sendToCardResults);
            }, function (results) {
                logger.error(message, reason);
            });
        }
    });

/*

function POST(URL, requestParams, requestBody, ResponseModel) {
    return $http({
        method: 'POST',
        url: URL + requestParams,
        data: requestBody
    }).then(serviceCallComplete)['catch'](serviceCallFailed);

    function serviceCallComplete(responseBody) {
        if (ResponseModel) {
            return angular.extend({}, new ResponseModel(), responseBody);
        }
        return responseBody;
    }

    function serviceCallFailed(error) {
        return $q.reject(error);
    }
}
*/
