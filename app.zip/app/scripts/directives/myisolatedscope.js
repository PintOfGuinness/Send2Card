'use strict';

/**
 * @ngdoc directive
 * @name send2CardApp.directive:myIsolatedScope
 * @description
 * # myIsolatedScope
 */
angular.module('send2CardApp')
    .directive('myIsolatedScope', function () {
        return {
            scope: {},
            template: 'Name: {{customer.name}}<br /> Street: {{customer.street}}',
            restrict: 'A',

        };
    });
