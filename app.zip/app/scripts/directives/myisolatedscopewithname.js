'use strict';

/**
 * @ngdoc directive
 * @name send2CardApp.directive:myIsolatedScopeWithName
 * @description
 * # myIsolatedScopeWithName
 */
angular.module('send2CardApp')
  .directive('myIsolatedScopeWithName', function () {
    return {
        scope: {
            name: '@',
            street: '@'
        },
        template: 'Name: {{ name }}, Street {{ street }}'
    };
  });
