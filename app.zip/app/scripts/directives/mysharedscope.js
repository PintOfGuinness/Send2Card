'use strict';

/**
 * @ngdoc directive
 * @name send2CardApp.directive:mySharedScope
 * @description
 * # mySharedScope
 */
angular.module('send2CardApp')
  .directive('mySharedScope', function () {
    return {
      template: 'Name: {{customer.name}}<br /> Street: {{customer.street}}',
     

    };
  });
