'use strict';

/**
 * @ngdoc directive
 * @name send2CardApp.directive:myIsolatedScopeWithControllerPassingParameter2
 * @description
 * # myIsolatedScopeWithControllerPassingParameter2
 */
angular.module('send2CardApp')
  .directive('myIsolatedScopeWithControllerPassingParameter2', function () {
    return {
        restrict: 'EA',
        scope: {
            datasource: '=',
            add: '&',
        },
        controller: function ($scope) {
            
            var counter = 0;
            $scope.customers = angular.copy( $scope.datasource ); 
            
            $scope.addCustomer = function () {
                counter++;
                //Call external scope's function
                var name = 'New Customer Added by Directive';

                $scope.add()(name);
 

                //Add new customer to directive scope
                $scope.customers.push({
                    name: name                
                });                
            };
        },
        template: '<button ng-click="addCustomer()">Change Data</button><ul>' +
                  '<li ng-repeat="cust in customers">{{ cust.name }}</li></ul>'
    };
  });
