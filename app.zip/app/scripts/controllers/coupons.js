'use strict';

/**
 * @ngdoc function
 * @name send2CardApp.controller:CouponsCtrl
 * @description
 * # CouponsCtrl
 * Controller of the send2CardApp
 */
angular.module('send2CardApp')
    .controller('CouponsCtrl', function (couponsService, sendToCardService) {

        var coupons = this;
        var URL = "data/sendToCardSuccess.json";       
        coupons.allCoupons = couponsService.allCoupons;
        couponsService.getAllCoupons();

        
        var requestBody = {
            extraCareCard: "2020202020",
            cpnSeqNbr: "29582525256",
            opCd: "V",
            ts: Date.now()
        }
        
 

        coupons.unSentCouponPath = "images/sendtocard.png";
        coupons.sentCouponPath = "images/sendtocarddone.png";
    
        coupons.sendCouponToCard = function () {
            
            sendToCardService.sendToCard(URL, requestBody);
            var results = coupons.sendToCardResults;
            console.log("Send To Card Service");                                    
            
            if(results === null) {
                isCouponSent = true;
            }
            
            return isCouponSent;
        };


    });
