'use strict';

/**
 * @ngdoc function
 * @name send2CardApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the send2CardApp
 */
angular.module('send2CardApp')
    .controller('CustomersCtrl', function ($scope) {

        var counter = 0;

        $scope.customer = {
            name: 'David',
            street: '1234 Anywhere St.'
        };

        $scope.customers = [];

        $scope.addCustomer = function (name) {
            counter++;
            $scope.customers.push({
                name: (name) ? name : 'New Customer' + counter,
                street: counter + ' Cedar Point St.'
            });
        };

        $scope.changeData = function () {
            counter++;
            $scope.customer = {
                name: 'James',
                street: counter + ' Cedar Point St.'
            };
        };

    });
