'use strict';

/**
 * @ngdoc function
 * @name send2CardApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the send2CardApp
 */
angular.module('send2CardApp')
  .controller('MainCtrl', function ($scope) {
    $scope.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
